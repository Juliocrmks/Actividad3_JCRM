import UIKit

// Declarar cuatro variables con asignacion explicita
var dato1:String = "string1"
var dato2:Int = 1
var dato3:Float = 1.1
var dato4:String = "String2"

// Declarar 4 variables con asignacion Inferida
var dato5 = "String3"
var dato6 = 1
var dato7 = 1.1
var dato8 = "String4"
// Declarar diccionario
var diccionario = [1:"Lunes"]

// Declarar Arreglo
var arreglo = [1,2,3,4,5,6,7,8,10]


